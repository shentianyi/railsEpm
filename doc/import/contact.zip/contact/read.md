命令：
rails runner script/import_data/import_contact.rb <文件路径> <修改确认>

参数说明：
文件路径：文件的结构应包含csv，及avatar文件夹，avatar中为头像文件
修改确人：可选，值为：
   0：不修改数据(默认)
   1：修改数据
   
