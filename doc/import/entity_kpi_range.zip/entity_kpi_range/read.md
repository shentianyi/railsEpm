命令：
rails runner script/import_data/import_entity_kpi_range.rb <文件路径>
 
